#!/usr/bin/env bash

echo -n '{"command":"GET", "name":"ExamSolutions.pdf", "offset": -89  , "length": 88 }' | nc localhost 4040
